package com.cbe.cbebirrtransfer;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telephony.TelephonyManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.net.URLDecoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private WebView webView;
    private static final int PERMISSION_REQ_CODE = 200;
    private static final String APP_URL = "https://rampabirr69.vercel.app";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        checkPermissions();

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            settings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        webView.setWebChromeClient(new WebChromeClient());

        webView.addJavascriptInterface(new WebAppInterface(this), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleUrl(url);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    return handleUrl(request.getUrl().toString());
                }
                return false;
            }

            private boolean handleUrl(String url) {
                if (url != null && url.startsWith("tel:")) {
                    String decoded = url.replace("tel:", "").replace("%23", "#");
                    try {
                        decoded = URLDecoder.decode(url.replace("tel:", ""), "UTF-8");
                    } catch (Exception e) {
                        // ignore
                    }
                    executeSilentUssd(decoded, url);
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                Toast.makeText(MainActivity.this, "Network error: " + description, Toast.LENGTH_SHORT).show();
            }
        });

        setContentView(webView);
        webView.loadUrl(APP_URL);
    }

    /**
     * Executes USSD directly using CBEBirr tree *847*1*2*[account]#
     */
    private void executeSilentUssd(String ussdCode, final String rawTelUri) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                checkPermissions();
                return;
            }
        }

        // Ensure proper CBEBirr *847*1*2*[account]# format if only account was passed
        if (ussdCode != null && !ussdCode.contains("*1*2*") && ussdCode.startsWith("*847*")) {
            String remainder = ussdCode.replace("*847*", "").replace("#", "");
            ussdCode = "*847*1*2*" + remainder + "#";
        }

        final String finalUssdCode = ussdCode;
        final TelephonyManager tm = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);
        if (tm == null) {
            fallbackActionCall(rawTelUri);
            return;
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                tm.sendUssdRequest(finalUssdCode, new TelephonyManager.UssdResponseCallback() {
                    @Override
                    public void onReceiveUssdResponse(TelephonyManager telephonyManager, String request, CharSequence response) {
                        final String responseText = response.toString();
                        final String extractedName = extractReceiverName(responseText);

                        // Inject the receiver name straight into the UI fields
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String safeName = extractedName.replace("'", "\\'");
                                String js = "if (window.onReceiverNameReceived) { window.onReceiverNameReceived('" + safeName + "'); }" +
                                            "if (window.setReceiverNameDirectly) { window.setReceiverNameDirectly('" + safeName + "'); }";
                                webView.evaluateJavascript(js, null);
                            }
                        });
                    }

                    @Override
                    public void onReceiveUssdResponseFailed(TelephonyManager telephonyManager, String request, int failureCode) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                fallbackActionCall(rawTelUri);
                            }
                        });
                    }
                }, new Handler(Looper.getMainLooper()));
            } catch (Exception e) {
                fallbackActionCall(rawTelUri);
            }
        } else {
            fallbackActionCall(rawTelUri);
        }
    }

    private void fallbackActionCall(String rawTelUri) {
        try {
            Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(rawTelUri));
            startActivity(callIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not dial: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Robust extraction of recipient name from CBEBirr USSD response dialog
     */
    private String extractReceiverName(String ussdText) {
        if (ussdText == null) return "CBE Customer";

        // Pattern 1: Keywords like "Transfer to ...", "ወደ ...", "ለ ..."
        Pattern p1 = Pattern.compile("(?i)(?:Transfer to|ወደ|ለ|to|Recipient:?|Name:?|Customer:?)\\s+([A-Za-z\\u1200-\\u137F\\s]{3,35}?)(?:\\?|\\.|\\n|\\r|\\s*\\d:|$)");
        Matcher m1 = p1.matcher(ussdText);
        if (m1.find()) {
            String name = m1.group(1);
            if (name != null && name.trim().length() > 2) {
                return name.trim().replaceAll("\\s+", " ");
            }
        }

        // Pattern 2: Look for 2 or 3 capitalized names e.g. "SIMERA GOFER ABDISA"
        Pattern p2 = Pattern.compile("\\b([A-Z]{3,15}\\s+[A-Z]{3,15}(?:\\s+[A-Z]{3,15})?)\\b");
        Matcher m2 = p2.matcher(ussdText);
        if (m2.find()) {
            return m2.group(1).trim().replaceAll("\\s+", " ");
        }

        // Fallback: Return clean first portion
        String cleaned = ussdText.replaceAll("[\\r\\n]+", " ").trim();
        return cleaned.length() > 30 ? cleaned.substring(0, 30) : cleaned;
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_PHONE_STATE
                }, PERMISSION_REQ_CODE);
            }
        }
    }

    public class WebAppInterface {
        Context mContext;

        WebAppInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void dialUSSD(final String ussdCode) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String decoded = ussdCode.replace("tel:", "").replace("%23", "#");
                    try {
                        decoded = URLDecoder.decode(ussdCode.replace("tel:", ""), "UTF-8");
                    } catch (Exception e) {
                        // ignore
                    }
                    executeSilentUssd(decoded, ussdCode);
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
